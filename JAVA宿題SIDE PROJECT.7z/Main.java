import java.util.*;

public class Main {
    
    public static void main(String[] args){
     test1 MainFrame = new test1();//執行test1.java
        MainFrame.setVisible(true);
      
    //new test1();   
    
    }
}